

import numpy as np
import math
import pandas as pd

import pickle
import timeit
import datetime

from random import shuffle
import collections
# from scipy import signal 
import os
import sys
from scipy.linalg import svd 
import collections

start = timeit.default_timer()

def remove_z(str):
    if str[0] == '0':
        return str[1]
    else:
        return str


        
def pack_ploterr():    
    df = pd.read_csv("data/err.csv")
    df[["season"]] = df[["season"]].astype(np.int32)
    df[["No"]] = df[["No"]].astype(np.int32)

    word = ""
    
    for ii in range(1,14):
        dt = df[df["season"]==ii]
        print(dt.shape[0])
        if(dt.shape[0]>0):
            
            list = dt['No'].tolist()
            print(list)
            plot_err(ii,list)
            


    


def diff(listA,listB):
    #find difference in a list
    retA = [i for i in listA if i in listB]          
    if retA:
        return True 
    else:
        return False    

# Filter the data:
# As Line_trip, Line_lightning Transformer_trip, Transformer_lightning 
# are really hard to distinish based on the paper Yuan, Yuxuan, et al. 
# "Learning-based real-time event identification using rich real PMU data." 
# IEEE Transactions on Power Systems 36.6 (2021): 5044-5055.

def rd_data(ii):
    path1 = "data/"
    df  = pd.read_csv(path1 +'Ss'+str(ii)+'.csv')
    full_ind = df.index

    path2 = "data/"
    dg = pd.read_csv(path2 +'muti.csv')
    # print("dg.shape",dg.shape)
    dg = dg[(dg["v"]==7)]
    ll = dg["new"].values.tolist()
    print(df.shape[0])
    st = []
    
    dt2 = df.loc[df["word"].str.contains("Line_Trip|Line_Lightning")==True ].index
    dt4 = df.loc[df["word"].str.contains("Transformer")==True ].index
    dt3 = df.loc[df["word"].str.contains("Transformer_Trip|Transformer_Lightning|Transformer_Planned")].index
    dt1 = df.loc[df.word2.isin(ll)].index
    ind1 = Uni(dt2,dt4)
    ind1 = Uni(dt1,ind1)
    # print(len(dt2))

    # print("  "+str(len(dt1)))
    # print(len(ind1))
    #step1 get rid of the data
    ind3 = list(set(full_ind)^set(ind1))
    ind2 = Uni(dt3,ind3)
    # print(len(ind2))


    #step2 label data again 
    dg = pd.read_csv(path2 +'muti.csv')
    # print("dg.shape",dg.shape)
    dg = dg[(dg["v"]==4)]
    ll = dg["new"].values.tolist()
    dt1 = df.loc[df.word2.isin(ll)].index
    dt2 = df.loc[df["word"].str.contains("Trans")==True ].index
    
    
    dg = pd.read_csv(path2 +'muti.csv')
    # print("dg.shape",dg.shape)
    dg = dg[(dg["v"]==5)]
    ll = dg["new"].values.tolist()
    dt3 = df.loc[df.word2.isin(ll)].index
    dt4 = df.loc[df["word"].str.contains("Freq")==True ].index    
    
    
    df.label = 0

    df.label[dt2] = 1
    df.label[dt1] = 1
    
    
    df.label[dt3] = 2
    df.label[dt4] = 2
    
    
    res = df.iloc[ind2]
    # res.pop("word")
    # res.pop("word2")
    # res.pop("season")
    # res.pop("No")
    
    
    
    res["r1"] = res["mean_r_aup"]/res["mean_r_adn"]
    res["r2"] = res["mean_r_aup"]/(res["mean_r_adn"]+res["mean_r_aup"])
    res["r3"] = res["mean_r_up"]/res["mean_r_dn"]
    
    # res["r4"] = res["mean_v_aup"]/res["mean_v_adn"]
    # res["r5"] = res["mean_v_aup"]/(res["mean_v_adn"]+res["mean_v_aup"])
    
    # res["r6"] = res["mean_i_aup"]/res["mean_i_adn"]
    # res["r7"] = res["mean_i_aup"]/(res["mean_i_adn"]+res["mean_i_aup"])
    
    # res["r8"] = res["max_v_dn"]/res["mean_v_dn"]
    # res["r9"] = res["max_i_dn"]/res["mean_i_dn"]
    
    # res["r10"] = res["max_v_up"]/res["mean_v_up"]
    # res["r11"] = res["max_i_up"]/res["mean_i_up"]
    
    y = res.pop("label")
    res = res.iloc[:,]
    res = res.replace([np.inf, -np.inf], np.nan)
    ind = res[res.isnull().T.any()].index
    res.loc[ind,:] = -1
    return res,y

# Get 2 list intersection
def Inter(listA,listB):
    return list(set(listA).intersection(set(listB)))
    
# Get 2 list Union
def Uni(listA,listB):
    return list(set(listA).union(set(listB)))
    
    
# Get ramdon split result    
def get_split(ii):        
    X,y = rd_vpm(ii)
    # print(X.shape)
    # print(y.shape)
    spliter(ii,y)

def spliter(num,y3):        
    a = np.arange(0,y3.shape[0])
    tr,val = train_test_split(a,test_size=0.2)   
    print(tr.shape)
    print(val.shape)
    path2 = 'index2/'
    np.save(path2+'tr_'+str(num)+'.npy',tr) 
    np.save(path2+'val_'+str(num)+'.npy',val)

# You can import the calculated zeta value here
def rd_zeta(ii):
    path1 = '../zeta/30/'
    # path1 = '../zeta/150/'
    p1 = open(path1 +'X_S'+str(ii)+'.pickle',"rb")
    pk1 = pickle.load(p1)
    print(pk1.shape)
    st = []
    # 
    for i in range(pk1.shape[0]):
        temp = pk1[i,7]
        
        st.append(p_ind(np.argmax(temp)))
    st = np.array(st)
    print("rd_zeta shape",st.shape)
    return st
    
    
# Consider the offset of zeta    
def p_ind(tt):
    # if(tt<180):
        # return 180
    if(tt>10500-180):
        return 10800-180
    else:
        return tt+205
        

def mid_data(ii):

    path2 = 'index2/'
    tr = np.load(path2+'tr_'+str(ii)+'.npy') 
    val = np.load(path2+'val_'+str(ii)+'.npy') 
    list1 = tr.astype(int).tolist()
    list2 = val.astype(int).tolist()
    # list = ['rocof','vp_m','ip_m','f']
    X,y = rd_data(ii)
 
    X_train = X.iloc[list1]
    y_train = y.iloc[list1]
    X_val = X.iloc[list2]
    y_val = y.iloc[list2]    
    
    

    return X_train,y_train,X_val,y_val
    
 
    
def top():

    X_train,y_train,X_val,y_val = mid_data(1)
    for k in range(2,13+1):
        X_train2,y_train2,X_val2,y_val2 = mid_data(k)
        # X_train = np.concatenate((X_train, X_train2), axis=0)
        # y_train = np.concatenate((y_train, y_train2), axis=0)
        
        # X_val = np.concatenate((X_val, X_val2), axis=0)
        # y_val = np.concatenate((y_val, y_val2), axis=0)   
        X_train = pd.concat([X_train, X_train2], axis=0)
        y_train = pd.concat([y_train, y_train2], axis=0)
        
        X_val = pd.concat([X_val, X_val2], axis=0)
        y_val = pd.concat([y_val, y_val2], axis=0)       
    
    # print(collections.Counter(y_train))
    # print(collections.Counter(y_val))

    
    X_train.pop("season")
    X_val.pop("season")
    X_train.pop("No")
    X_val.pop("No")
    
    print(X_train.shape)
    print(y_train.shape)
    print(X_val.shape)
    print(y_val.shape)        
    
    return X_train,y_train,X_val,y_val
    
def p_ind2(tt):
    if(tt<720):
        return 360
    if(tt>10800-360):
        return 10800-360
    else:
        return tt
        


    
def main():
    s1 = timeit.default_timer() 
    # for i in range(1,14):
        # get_split(i)
    # mid_data2(1)
    # rd_rof(3)
    top()
    # pack_ploterr()
    # rd_vpm(1)
    s2 = timeit.default_timer()  
    print ('Runing time is (mins):',round((s2 -s1)/60,2))
    
if __name__ == '__main__':  
    main()
