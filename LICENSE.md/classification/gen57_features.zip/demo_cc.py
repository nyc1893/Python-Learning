

# import matplotlib.pyplot as plt
# import tensorflow as tf
import numpy as np
import math
import pandas as pd
import time  
# from sklearn import metrics  
import pickle as pickle  
import timeit
# import matplotlib.pyplot as plt
# from scipy.linalg import svd 
# import time
import timeit
# from random import randint
# import math
# 


# To calculate the area difference
def cal_diparea(temp,mm):
    sum1 =0
    sum2 =0
    for i in range(temp.shape[0]):
        if(temp[i]<mm):
            sum1+= mm-temp[i]
        elif (temp[i]>mm):
            sum2+= temp[i] - mm
    return sum1,sum2
    
# To calculate the amplitude difference
def cal_dif(temp):
    d = int(temp.shape[0]/2)
    m1 = 0
    m2 = 0
    for i in range(d):
        temp1 = temp[i]-temp[i+d]
        temp2 = temp[i+d]-temp[i]
        if(temp1>m1):
            m1 = temp1
        if(temp2>m2):
            m2 = temp2
    # print(m1,m2)
    return m1,m2
    
# This function is to read data on pickleset
def rd_data(ii,k):
    
    # path1 = '../../../pickleset1/'
    # list = ['vp_m','vp_a','ip_m','ip_a','f','rocof']
    list = ['vp_m','ip_m','rocof']
    p1 = open('X_S'+str(ii)+'_'+str(list[k])+'_6.pickle',"rb")
    pk1 = pickle.load(p1)
    
    pk3  = pd.read_csv('y_S'+str(ii)+'_'+str(list[k])+'_6.csv')
   
    X_train = pk1
    y_train = pk3.values

    X_train=X_train.transpose(0,1,3,2)

    X_train = proces3(X_train,k) 

    return X_train,y_train

# This function is to package the vpm, ipm, and rocof
def datapack(ii):
    k =0
    a,y = rd_data(ii,k)
    for k in range(1,2+1):
        a2,_ = rd_data(ii,k)
        a = np.concatenate((a, a2), axis=2)  

    print(a.shape)
    print(y.shape)
    return a,y
    
# This function for Nornalization
def proces3(data,k):
    st1 =[]
    data = np.squeeze(data)
    
    for j in range(0,data.shape[0]):
        st2=[]
        for i in range(0,data.shape[1]):
            if(k == 0):
                temp = data[j,i,:]/np.mean(data[j,i,:])
            elif(k == 1):
                temp = np.deg2rad(data[j,i,:])
            elif(k == 2):
                temp = data[j,i,:]/np.mean(data[j,i,:])            
            elif(k == 3):
                temp = np.deg2rad(data[j,i,:])                
            elif(k == 4):
                temp = data[j,i,:]/60          
            elif(k == 5):
                temp = data[j,i,:]      
            st2.append(temp)
        st1.append(st2)

    st1 = np.array(st1)
    st1 = st1[:,:,np.newaxis,:]
    # print(st1.shape)
    return st1
    
    




#This function generate a 2 entries sub dataset from the pickle1  folder.
def rd(ii,k):

    path1 = '../../../pickleset1/'
    # list = ['vp_m','vp_a','ip_m','ip_a','f','rocof']
    list = ['vp_m','ip_m','rocof']
    p1 = open(path1 +'X_S'+str(ii)+'_'+str(list[k])+'_6.pickle',"rb")
    pk1 = pickle.load(p1)
    print(pk1.shape)
    
    pk3  = pd.read_csv(path1 +'y_S'+str(ii)+'_'+str(list[k])+'_6.csv')
    print(pk3.shape)
    
    
    res = pk1[:2]
    pickle_out = open('X_S'+str(ii)+'_'+str(list[k])+'_6.pickle',"wb")
    pickle.dump(res, pickle_out, protocol=2)
    pickle_out.close()   
    print(res.shape)

    pk4 = pk3.iloc[:2]
    print(pk4.shape)
    pk4.to_csv('y_S'+str(ii)+'_'+str(list[k])+'_6.csv',index = None)
    

# This function is to get F1-F6 features in our paper
# The input of x should be:
# Dimension No.1:number of events
# Dimension No.2:number of input PMU numbers, here for IC_B data is 23
# Dimension No.3:number of features , here it is vpm, ipm, rocof
# Dimension No.4:measurements of the input signal
    # You can choose any length of the window size in Dimension No.4
    # 60 measurements means 1 sec. It requires you to locate the 
    # suitable event time window first e.g., by using zeta value to locate.
    
def get_feature(x,j,feature):
    up = []
    dn = []
    sup = []
    sdn = []
    dup =[]
    ddn =[]
    global reg
    for i in range(23):
        temp = x[j,i,feature,:]
        mm = np.mean(x[j,i,0, :])
        m1,m2 = cal_dif(temp)
        m3,m4 = cal_diparea(temp,mm)

        m5 = np.max(temp)-mm
        m6 = mm-np.min(temp)
        up.append(m5)
        dn.append(m6)
        
        sdn.append(m3)
        sup.append(m4)
        
        dup.append(m1)
        ddn.append(m2)

    return up,dn,dup,ddn,sup,sdn
    
# This function is to get the statical value of F1-F6 features in our paper
def cal(ii):
    x,y = datapack(ii)
    print(x.shape)
    

    v= 0
    st =[]
    label=[]
    # x.shape[0]
    

    for j in range(x.shape[0]):


        list_v_up = []
        list_v_dn = []
        list_v_dup = []
        list_v_ddn = []       
        list_v_aup =[]
        list_v_adn =[]
        
        list_i_up = []
        list_i_dn = []
        list_i_dup = []
        list_i_ddn = []       
        list_i_aup =[]
        list_i_adn =[]

        list_r_up = []
        list_r_dn = []
        list_r_dup = []
        list_r_ddn = []       
        list_r_aup =[]
        list_r_adn =[]
        
        list_v_up,list_v_dn,list_v_dup,list_v_ddn,list_v_aup,list_v_adn = get_feature(x,j,0)
        list_i_up,list_i_dn,list_i_dup,list_i_ddn,list_i_aup,list_i_adn = get_feature(x,j,1)
        list_r_up,list_r_dn,list_r_dup,list_r_ddn,list_r_aup,list_r_adn = get_feature(x,j,2)
        

        sd = []
        sd.append( np.max(list_v_up))
        sd.append( np.mean(list_v_up))
        sd.append( np.min(list_v_up))
        
        sd.append( np.max(list_v_dn))
        sd.append( np.mean(list_v_dn))
        sd.append( np.min(list_v_dn))
        
        sd.append( np.max(list_v_dup))
        sd.append( np.mean(list_v_dup))
        sd.append( np.min(list_v_dup))
        
        sd.append( np.max(list_v_ddn))
        sd.append( np.mean(list_v_ddn))
        sd.append( np.min(list_v_ddn))
        
        sd.append( np.max(list_v_aup))
        sd.append( np.mean(list_v_aup))
        sd.append( np.min(list_v_aup))
        
        sd.append( np.max(list_v_adn))
        sd.append( np.mean(list_v_adn))
        sd.append( np.min(list_v_adn))


        sd.append( np.max(list_i_up))
        sd.append( np.mean(list_i_up))
        sd.append( np.min(list_i_up))
        
        sd.append( np.max(list_i_dn))
        sd.append( np.mean(list_i_dn))
        sd.append( np.min(list_i_dn))
        
        sd.append( np.max(list_i_dup))
        sd.append( np.mean(list_i_dup))
        sd.append( np.min(list_i_dup))
        
        sd.append( np.max(list_i_ddn))
        sd.append( np.mean(list_i_ddn))
        sd.append( np.min(list_i_ddn))
        
        sd.append( np.max(list_i_aup))
        sd.append( np.mean(list_i_aup))
        sd.append( np.min(list_i_aup))
        
        sd.append( np.max(list_i_adn))
        sd.append( np.mean(list_i_adn))
        sd.append( np.min(list_i_adn))        


        sd.append( np.max(list_r_up))
        sd.append( np.mean(list_r_up))
        sd.append( np.min(list_r_up))
        
        sd.append( np.max(list_r_dn))
        sd.append( np.mean(list_r_dn))
        sd.append( np.min(list_r_dn))
        
        sd.append( np.max(list_r_dup))
        sd.append( np.mean(list_r_dup))
        sd.append( np.min(list_r_dup))
        
        sd.append( np.max(list_r_ddn))
        sd.append( np.mean(list_r_ddn))
        sd.append( np.min(list_r_ddn))
        
        sd.append( np.max(list_r_aup))
        sd.append( np.mean(list_r_aup))
        sd.append( np.min(list_r_aup))
        
        sd.append( np.max(list_r_adn))
        sd.append( np.mean(list_r_adn))
        sd.append( np.min(list_r_adn))       

        
        v+=1
        st.append(sd)
        label.append(y[j,0])
        
    st= np.array(st)
    label = np.array(label)
    df = pd.DataFrame(st)
    
    print(df.head())
     # This part we got 54 features 
    list1 = ["max","mean","min"]
    # list_v_up,list_v_dn,list_v_dup,list_v_ddn,list_v_aup,list_v_adn
    
    
    # v_up: Amplitude above the average
    # v_dn: Amplitude below the average
    # v_dup: voltage ramp up rate
    # v_ddn: voltage ramp down rate
    # v_aup: voltage signal Area above the average
    # v_adn: voltage signal Area below the average
    
    list2 = ["v_up","v_dn","v_dup","v_ddn","v_aup","v_adn",
            "i_up","i_dn","i_dup","i_ddn","i_aup","i_adn",
            "r_up","r_dn","r_dup","r_ddn","r_aup","r_adn"
            ]
    list3 =[]
    
    for i in range(0,len(list2)):
        for j in range(0,len(list1)):
            list3.append(list1[j]+"_"+list2[i])      
    # print(list3)
    df.columns = list3
    df["label"] = label
    

    
    
    # This part is to generate the derivative 3 additional features 
    # After that we got 57 features
    df["r1"] = df["mean_r_aup"]/df["mean_r_adn"]
    df["r2"] = df["mean_r_aup"]/(df["mean_r_adn"]+df["mean_r_aup"])
    df["r3"] = df["mean_r_up"]/df["mean_r_dn"]
    print(df.head())
    print(df.shape)
    res = df.iloc[:,]
    
    # This part will handle the abnormal value and it is optional based on the result
    
    res = res.replace([np.inf, -np.inf], np.nan)
    ind = res[res.isnull().T.any()].index
    res.loc[ind,:] = -1    

    res.to_csv("see.csv", index = None)


def main():
    s1 = timeit.default_timer()  
    

    for ii in range(1,1+1):

        cal(ii)
        # rd(ii,0)
        # rd(ii,1)
        # rd(ii,2)
        
    s2 = timeit.default_timer()
    print('Time:(min) ', (s2 - s1)/60 )
if __name__ == '__main__':  

    main()

